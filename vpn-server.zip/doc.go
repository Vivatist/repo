// Makefile-подобная сборка для NovaVPN Server.
// Используйте: go run build.go [command]
//
// Или просто:
//   go build -o novavpn-server ./cmd/vpnserver/

package main
